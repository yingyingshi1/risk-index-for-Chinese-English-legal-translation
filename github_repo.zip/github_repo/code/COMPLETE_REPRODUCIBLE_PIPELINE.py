# =========================================================================
# COMPLETE REPRODUCIBLE PIPELINE
# Translation Risk Index (RI) Framework - CFA Judgement Corpus Study
# =========================================================================
# This file reproduces every real step of the project, in order:
#   STAGE 1  - Setup, Drive mount, corpus loading and cleaning
#   STAGE 2  - Build the two experimental samples (random + targeted)
#   STAGE 3  - Load Qwen2.5-7B-Instruct, run real translation, score
#   STAGE 4  - Real baseline metrics (BLEU, BERTScore)
#   STAGE 5  - Blind human-labelling export  <-- MANUAL STEP, CANNOT SKIP
#   STAGE 6  - Merge human labels with hidden scores, evaluate (original formula)
#   STAGE 7  - Calibrate thresholds honestly (train/held-out split)
#   STAGE 8  - Detect and exclude misaligned rows
#   STAGE 9  - Binary analysis (Low Risk vs Not Low Risk)
#   STAGE 10 - Refined deontic formula (groups synonymous obligation terms)
#   STAGE 11 - Final calibration and binary analysis on refined formula
#   STAGE 12 - Extract real case-study examples
#
# Every number in the paper's Methodology, Results, and Discussion
# sections should trace back to a specific stage in this file.
# =========================================================================

# =========================================================================
# STAGE 1 - SETUP AND CORPUS LOADING/CLEANING
# =========================================================================
# Run in a fresh Colab session with GPU. Confirm first: !nvidia-smi
# Install first, in its own cell, then restart runtime:
# !pip install -q transformers accelerate bitsandbytes sentence-transformers \
#     spacy datasets sacrebleu bert-score pandas matplotlib seaborn tqdm scikit-learn
# !python -m spacy download en_core_web_sm -q

from google.colab import drive
drive.mount('/content/drive')

import os, re, random
import numpy as np
import pandas as pd
import spacy
import matplotlib.pyplot as plt
import seaborn as sns
import torch
from datasets import load_dataset
from sentence_transformers import SentenceTransformer
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline, BitsAndBytesConfig
from sacrebleu import corpus_bleu
from bert_score import score as bert_score
from tqdm import tqdm
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from sklearn.model_selection import train_test_split

SEED = 42
random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)

OUTPUT_DIR = "/content/drive/MyDrive/translation_risk_paper"
os.makedirs(OUTPUT_DIR, exist_ok=True)

LABELS_ORDER = ["Low Risk", "Medium Risk", "High Risk"]
BINARY_LABELS = ["Low Risk", "Not Low Risk"]

def normalise_labels(series):
    label_map = {"low": "Low Risk", "low risk": "Low Risk",
                 "medium": "Medium Risk", "medium risk": "Medium Risk", "med": "Medium Risk",
                 "high": "High Risk", "high risk": "High Risk"}
    s = series.astype(str).str.strip()
    return s.apply(lambda x: label_map.get(x.lower(), x))

print("Loading CFA Judgement Corpus 97-22...")
dataset = load_dataset("xxuan-nlp/CFA_Judgement_Corpus_97-22")
corpus_df = pd.DataFrame(dataset['train'])
corpus_df['en'] = corpus_df['translation'].apply(lambda x: x['en'])
corpus_df['zh_hk'] = corpus_df['translation'].apply(lambda x: x['zh-HK'])
corpus_df = corpus_df.drop(columns=['translation'])
print(f"Raw segments: {len(corpus_df)}")

# Filter to substantive segments (>= 15 English words)
corpus_df['en_word_count'] = corpus_df['en'].apply(lambda x: len(str(x).split()))
corpus_df = corpus_df[corpus_df['en_word_count'] >= 15].copy()
print(f"Substantive segments: {len(corpus_df)}")

# Repair tab-concatenated contamination (Chinese fragment + tab + real English)
def cjk_ratio(text):
    text = str(text)
    return len(re.findall(r'[\u4e00-\u9fff]', text)) / len(text) if len(text) > 0 else 1.0

def repair_row(text):
    text = str(text)
    if cjk_ratio(text) <= 0.05:
        return text, "unchanged"
    parts = [p.strip() for p in text.split('\t') if p.strip()]
    if len(parts) <= 1:
        return None, "unrecoverable"
    candidates = sorted([(p, cjk_ratio(p)) for p in parts], key=lambda x: x[1])
    best_part, best_ratio = candidates[0]
    if best_ratio <= 0.05 and len(best_part.split()) >= 5:
        return best_part, "repaired"
    return None, "unrecoverable"

repaired, statuses = [], []
for text in corpus_df['en']:
    r, s = repair_row(text)
    repaired.append(r); statuses.append(s)
corpus_df['en_repaired'] = repaired
corpus_df['repair_status'] = statuses

corpus_df = corpus_df[corpus_df['repair_status'].isin(['unchanged', 'repaired'])].copy()
corpus_df['en'] = corpus_df.apply(lambda r: r['en_repaired'] if r['repair_status'] == 'repaired' else r['en'], axis=1)
corpus_df = corpus_df.drop(columns=['en_repaired', 'repair_status', 'en_word_count'])

corpus_df['en_norm'] = corpus_df['en'].apply(lambda x: re.sub(r'\s+', ' ', str(x)).strip())
corpus_df = corpus_df.drop_duplicates(subset='en_norm').drop(columns=['en_norm'])
print(f"Final clean corpus size: {len(corpus_df)}")

# =========================================================================
# STAGE 2 - BUILD THE TWO EXPERIMENTAL SAMPLES
# =========================================================================
MODALS = ['shall', 'must', 'should', 'may']
modal_pattern = r'\b(?:' + '|'.join(MODALS) + r')\b'
corpus_df['contains_modal'] = corpus_df['en'].str.contains(modal_pattern, case=False, regex=True)

random_sample = corpus_df.sample(n=min(500, len(corpus_df)), random_state=SEED).copy()
random_sample['sample_type'] = 'random_primary'

modal_segments = corpus_df[corpus_df['contains_modal']].copy()
modal_segments = modal_segments[~modal_segments.index.isin(random_sample.index)]
targeted_sample = modal_segments.sample(n=min(200, len(modal_segments)), random_state=SEED).copy()
targeted_sample['sample_type'] = 'targeted_diagnostic'

random_sample = random_sample.drop(columns=['contains_modal'])
targeted_sample = targeted_sample.drop(columns=['contains_modal'])
random_sample.to_csv(f"{OUTPUT_DIR}/experiment1_random_sample.csv", index=False)
targeted_sample.to_csv(f"{OUTPUT_DIR}/experiment2_targeted_sample.csv", index=False)
print(f"Experiment 1 (random): {len(random_sample)}  |  Experiment 2 (targeted): {len(targeted_sample)}")

# =========================================================================
# STAGE 3 - LOAD MODEL, RUN REAL TRANSLATION AND ORIGINAL SCORING
# =========================================================================
if not torch.cuda.is_available():
    raise RuntimeError("No GPU detected. Runtime -> Change runtime type -> GPU.")

MODEL_ID = "Qwen/Qwen2.5-7B-Instruct"
tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
bnb_config = BitsAndBytesConfig(load_in_4bit=True)
model = AutoModelForCausalLM.from_pretrained(MODEL_ID, quantization_config=bnb_config, device_map="auto")
translator = pipeline("text-generation", model=model, tokenizer=tokenizer)

semantic_encoder = SentenceTransformer('all-mpnet-base-v2')
nlp = spacy.load('en_core_web_sm')

DEONTIC_WEIGHTS_V1 = {'shall': 1.0, 'must': 1.0, 'should': 0.4, 'may': 0.1}
SYSTEM_PROMPT = (
    "You are a professional legal translator. Translate the following "
    "Traditional Chinese legal text into English. Maintain exact legal "
    "obligations and binding terminology. Do not smooth over or omit "
    "terms related to liability, penalties, or compliance. Output only "
    "the English translation, with no preamble or explanation."
)

def translate_with_llm(zh_text):
    messages = [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": zh_text}]
    prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    output = translator(prompt, max_new_tokens=256, do_sample=False, pad_token_id=tokenizer.eos_token_id)
    return output[0]['generated_text'][len(prompt):].strip()

def calculate_l_sem(ref_text, llm_text):
    e = semantic_encoder.encode([str(ref_text), str(llm_text)], show_progress_bar=False)
    cos_sim = np.dot(e[0], e[1]) / (np.linalg.norm(e[0]) * np.linalg.norm(e[1]))
    return float(np.clip(1.0 - cos_sim, 0.0, 1.0))

def calculate_p_legal_v1(ref_text, llm_text):
    def vec(text):
        doc = nlp(str(text).lower())
        v = np.zeros(len(DEONTIC_WEIGHTS_V1))
        keys = list(DEONTIC_WEIGHTS_V1.keys())
        for t in doc:
            if t.text in DEONTIC_WEIGHTS_V1:
                v[keys.index(t.text)] += DEONTIC_WEIGHTS_V1[t.text]
        return v
    delta = np.sum(np.abs(vec(ref_text) - vec(llm_text)))
    return float((2 / (1 + np.exp(-delta))) - 1)

ALPHA = 0.5

def run_experiment(sample_df, tag):
    llm_out, l_sems, p_legals, ris = [], [], [], []
    for idx, row in tqdm(sample_df.iterrows(), total=len(sample_df), desc=tag):
        llm_text = translate_with_llm(row['zh_hk'])
        l_sem = calculate_l_sem(row['en'], llm_text)
        p_legal = calculate_p_legal_v1(row['en'], llm_text)
        ri = ALPHA * l_sem + (1 - ALPHA) * p_legal
        llm_out.append(llm_text); l_sems.append(l_sem); p_legals.append(p_legal); ris.append(ri)
    sample_df = sample_df.copy()
    sample_df['llm_translation'] = llm_out
    sample_df['L_sem'] = l_sems
    sample_df['P_legal'] = p_legals
    sample_df['Risk_Index'] = ris
    return sample_df

results_exp1 = run_experiment(random_sample, "experiment1_random")
results_exp2 = run_experiment(targeted_sample, "experiment2_targeted")

# =========================================================================
# STAGE 4 - REAL BASELINE METRICS
# =========================================================================
for res, tag in [(results_exp1, "experiment1_random"), (results_exp2, "experiment2_targeted")]:
    res['BLEU'] = [corpus_bleu([h], [[r]]).score for r, h in zip(res['en'], res['llm_translation'])]
    P, R, F1 = bert_score(res['llm_translation'].tolist(), res['en'].tolist(), lang='en', verbose=False)
    res['BERTScore_F1'] = F1.numpy()
    res.to_csv(f"{OUTPUT_DIR}/results_{tag}.csv", index=False)

print("Stage 1-4 complete. Real translation and scoring finished for both experiments.")

# =========================================================================
# STAGE 5 - BLIND HUMAN-LABELLING EXPORT  ***MANUAL STEP - DO NOT SKIP***
# =========================================================================
# This step CANNOT be automated. A human domain expert must read each
# segment (blind to the model's own scores) and assign Low/Medium/High
# Risk. To make it easy we have created a standalone labelling tool (translation_risk_labelling_tool.html)
# for a browser-based way to do this efficiently.
def build_blind_annotation_file(results_df, sample_type_tag, n_to_label=100):
    df = results_df.reset_index(drop=True)
    df['row_id'] = df.index.map(lambda i: f"{sample_type_tag}_{i}")
    to_label = df.sample(n=min(n_to_label, len(df)), random_state=SEED).copy()
    blind_df = to_label[['row_id', 'zh_hk', 'en', 'llm_translation']].copy()
    blind_df['human_risk_label'] = ""
    blind_df.to_csv(f"{OUTPUT_DIR}/BLIND_annotation_{sample_type_tag}.csv", index=False)
    key_df = to_label[['row_id', 'L_sem', 'P_legal', 'Risk_Index']].copy()
    key_df.to_csv(f"{OUTPUT_DIR}/KEY_do_not_open_yet_{sample_type_tag}.csv", index=False)

build_blind_annotation_file(results_exp1, "experiment1_random", n_to_label=100)
build_blind_annotation_file(results_exp2, "experiment2_targeted", n_to_label=100)

print("\n*** STOP HERE ***")
print("Open both BLIND_annotation_*.csv files (or use the labelling tool)")
print("and fill in human_risk_label for every row before continuing to Stage 6.")
print("This is a real manual step - it cannot and should not be automated.")

# =========================================================================
# STAGE 6 - MERGE HUMAN LABELS WITH HIDDEN SCORES, EVALUATE (ORIGINAL FORMULA)
# =========================================================================
# Run this AFTER labelling both BLIND files by hand.
def load_and_merge(tag):
    blind_df = pd.read_csv(f"{OUTPUT_DIR}/BLIND_annotation_{tag}.csv")
    key_df = pd.read_csv(f"{OUTPUT_DIR}/KEY_do_not_open_yet_{tag}.csv")
    blind_df['human_risk_label'] = normalise_labels(blind_df['human_risk_label'])
    valid = blind_df[blind_df['human_risk_label'].isin(LABELS_ORDER)].copy()
    merged = valid.merge(key_df, on='row_id', how='left').dropna(subset=['Risk_Index'])
    return merged

exp1_labelled = load_and_merge("experiment1_random")
exp2_labelled = load_and_merge("experiment2_targeted")
combined = pd.concat([exp1_labelled, exp2_labelled], ignore_index=True)
combined.to_csv(f"{OUTPUT_DIR}/final_labelled_results_combined.csv", index=False)
print(f"Combined labelled dataset: {len(combined)} rows")

# =========================================================================
# STAGE 7 - CALIBRATE THRESHOLDS  (TRAIN/HELD-OUT SPLIT)
# =========================================================================
def classify_ri(ri, low_med, med_high):
    if ri >= med_high: return "High Risk"
    elif ri >= low_med: return "Medium Risk"
    else: return "Low Risk"

def calibrate_three_class(df, ri_col):
    calib_df, holdout_df = train_test_split(df, test_size=0.30, random_state=SEED, stratify=df['human_risk_label'])
    best_f1, best_low_med, best_med_high = -1, None, None
    for low_med in np.arange(0.02, 0.60, 0.02):
        for med_high in np.arange(0.02, 0.60, 0.02):
            if med_high <= low_med: continue
            preds = calib_df[ri_col].apply(lambda ri: classify_ri(ri, low_med, med_high))
            f1 = f1_score(calib_df['human_risk_label'], preds, labels=LABELS_ORDER, average='macro', zero_division=0)
            if f1 > best_f1:
                best_f1, best_low_med, best_med_high = f1, low_med, med_high
    holdout_preds = holdout_df[ri_col].apply(lambda ri: classify_ri(ri, best_low_med, best_med_high))
    acc = accuracy_score(holdout_df['human_risk_label'], holdout_preds)
    f1_macro = f1_score(holdout_df['human_risk_label'], holdout_preds, labels=LABELS_ORDER, average='macro', zero_division=0)
    baseline = (holdout_df['human_risk_label'] == calib_df['human_risk_label'].mode()[0]).mean()
    return {"low_med": best_low_med, "med_high": best_med_high, "accuracy": acc, "macro_f1": f1_macro,
            "baseline": baseline, "holdout_df": holdout_df, "holdout_preds": holdout_preds}

result_v1 = calibrate_three_class(combined, "Risk_Index")
print(f"ORIGINAL formula: thresholds={result_v1['low_med']:.2f}/{result_v1['med_high']:.2f}  "
      f"baseline={result_v1['baseline']:.3f}  accuracy={result_v1['accuracy']:.3f}  macro_f1={result_v1['macro_f1']:.3f}")

# =========================================================================
# STAGE 8 - DETECT AND EXCLUDE MISALIGNED ROWS
# =========================================================================
def extract_numbers(text):
    return set(re.findall(r'\d+', str(text)))

combined['llm_numbers'] = combined['llm_translation'].apply(extract_numbers)
combined['ref_numbers'] = combined['en'].apply(extract_numbers)
combined['alignment_check'] = combined.apply(
    lambda r: "SUSPECT_MISALIGNED" if len(r['llm_numbers']) > 0 and len(r['llm_numbers'] & r['ref_numbers']) == 0 else "ok",
    axis=1
)
suspect_ids = combined[combined['alignment_check'] == 'SUSPECT_MISALIGNED']['row_id'].tolist()
print(f"Suspected misaligned rows (verify manually before excluding): {suspect_ids}")

# Confirmed misaligned rows from manual verification in this study:
CONFIRMED_MISALIGNED = ["experiment1_random_485", "experiment2_targeted_122"]
df_clean = combined[~combined['row_id'].isin(CONFIRMED_MISALIGNED)].copy()
df_clean = df_clean.drop(columns=['llm_numbers', 'ref_numbers', 'alignment_check'])
df_clean.to_csv(f"{OUTPUT_DIR}/final_labelled_results_CLEANED.csv", index=False)
print(f"Rows after exclusion: {len(df_clean)}")

result_v1_clean = calibrate_three_class(df_clean, "Risk_Index")
print(f"ORIGINAL formula (cleaned): accuracy={result_v1_clean['accuracy']:.3f}  macro_f1={result_v1_clean['macro_f1']:.3f}")

# =========================================================================
# STAGE 9 - BINARY ANALYSIS (LOW RISK vs NOT LOW RISK)
# =========================================================================
def classify_binary(ri, threshold):
    return "Low Risk" if ri < threshold else "Not Low Risk"

def calibrate_binary(df, ri_col):
    df = df.copy()
    df['binary_label'] = df['human_risk_label'].apply(lambda x: "Low Risk" if x == "Low Risk" else "Not Low Risk")
    calib_df, holdout_df = train_test_split(df, test_size=0.30, random_state=SEED, stratify=df['human_risk_label'])
    best_f1, best_t = -1, None
    for t in np.arange(0.02, 0.60, 0.01):
        preds = calib_df[ri_col].apply(lambda ri: classify_binary(ri, t))
        f1 = f1_score(calib_df['binary_label'], preds, labels=BINARY_LABELS, average='macro', zero_division=0)
        if f1 > best_f1: best_f1, best_t = f1, t
    holdout_preds = holdout_df[ri_col].apply(lambda ri: classify_binary(ri, best_t))
    acc = accuracy_score(holdout_df['binary_label'], holdout_preds)
    f1_macro = f1_score(holdout_df['binary_label'], holdout_preds, labels=BINARY_LABELS, average='macro', zero_division=0)
    rec_pc = recall_score(holdout_df['binary_label'], holdout_preds, labels=BINARY_LABELS, average=None, zero_division=0)
    baseline = (holdout_df['binary_label'] == calib_df['binary_label'].mode()[0]).mean()
    return {"threshold": best_t, "accuracy": acc, "macro_f1": f1_macro, "baseline": baseline,
            "low_risk_recall": rec_pc[0], "not_low_risk_recall": rec_pc[1]}

binary_v1 = calibrate_binary(df_clean, "Risk_Index")
print(f"Binary (original formula): threshold={binary_v1['threshold']:.2f}  accuracy={binary_v1['accuracy']:.3f}  "
      f"macro_f1={binary_v1['macro_f1']:.3f}  LowRisk_recall={binary_v1['low_risk_recall']:.3f}  "
      f"NotLowRisk_recall={binary_v1['not_low_risk_recall']:.3f}")

# =========================================================================
# STAGE 10 - REFINED DEONTIC FORMULA (GROUPS SYNONYMOUS OBLIGATION TERMS)
# =========================================================================
DEONTIC_CATEGORIES_V2 = {
    "strong_obligation": {"weight": 1.0, "phrases": ["shall", "must", "obliged to", "required to", "bound to"]},
    "soft_obligation":   {"weight": 0.4, "phrases": ["should", "ought to"]},
    "permission":        {"weight": 0.1, "phrases": ["may", "entitled to", "permitted to"]},
}

def extract_deontic_vector_v2(text):
    text = str(text).lower()
    return np.array([
        sum(len(re.findall(r'\b' + re.escape(p) + r'\b', text)) for p in info["phrases"]) * info["weight"]
        for info in DEONTIC_CATEGORIES_V2.values()
    ])

def calculate_p_legal_v2(ref_text, llm_text):
    delta = np.sum(np.abs(extract_deontic_vector_v2(ref_text) - extract_deontic_vector_v2(llm_text)))
    return float((2 / (1 + np.exp(-delta))) - 1)

df_clean['P_legal_v2'] = df_clean.apply(lambda r: calculate_p_legal_v2(r['en'], r['llm_translation']), axis=1)
df_clean['Risk_Index_v2'] = ALPHA * df_clean['L_sem'] + (1 - ALPHA) * df_clean['P_legal_v2']
df_clean.to_csv(f"{OUTPUT_DIR}/final_labelled_results_REFINED_FORMULA.csv", index=False)

# =========================================================================
# STAGE 11 - FINAL CALIBRATION AND BINARY ANALYSIS ON REFINED FORMULA
# =========================================================================
result_v2 = calibrate_three_class(df_clean, "Risk_Index_v2")
print(f"REFINED formula: thresholds={result_v2['low_med']:.2f}/{result_v2['med_high']:.2f}  "
      f"accuracy={result_v2['accuracy']:.3f}  macro_f1={result_v2['macro_f1']:.3f}")

binary_v2 = calibrate_binary(df_clean, "Risk_Index_v2")
print(f"Binary (refined formula): accuracy={binary_v2['accuracy']:.3f}  macro_f1={binary_v2['macro_f1']:.3f}  "
      f"LowRisk_recall={binary_v2['low_risk_recall']:.3f}  NotLowRisk_recall={binary_v2['not_low_risk_recall']:.3f}")

cm = confusion_matrix(result_v2['holdout_df']['human_risk_label'], result_v2['holdout_preds'], labels=LABELS_ORDER)
plt.figure(figsize=(7, 5))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=LABELS_ORDER, yticklabels=LABELS_ORDER)
plt.title(f"FINAL Confusion Matrix - Refined Formula (N={len(result_v2['holdout_df'])})")
plt.xlabel("Predicted Risk Tier"); plt.ylabel("Human Judgement (Blind)")
plt.tight_layout()
plt.savefig(f"{OUTPUT_DIR}/FINAL_confusion_matrix.png", dpi=300)
plt.show()

# =========================================================================
# STAGE 12 - EXTRACT REAL CASE-STUDY EXAMPLES
# =========================================================================
df_clean['predicted_risk_tier'] = df_clean['Risk_Index_v2'].apply(
    lambda ri: classify_ri(ri, result_v2['low_med'], result_v2['med_high'])
)

highest_ri = df_clean.loc[df_clean['Risk_Index_v2'].idxmax()]
missed = df_clean[(df_clean['human_risk_label'] == 'High Risk') & (df_clean['predicted_risk_tier'] == 'Low Risk')]
false_alarm = df_clean[(df_clean['human_risk_label'] == 'Low Risk') & (df_clean['predicted_risk_tier'] == 'High Risk')]

case_rows = [highest_ri]
if len(missed) > 0: case_rows.append(missed.loc[missed['Risk_Index_v2'].idxmin()])
if len(false_alarm) > 0: case_rows.append(false_alarm.loc[false_alarm['Risk_Index_v2'].idxmax()])

pd.DataFrame(case_rows).to_csv(f"{OUTPUT_DIR}/FINAL_case_studies.csv", index=False)

# =========================================================================
# FINAL SUMMARY - ALL KEY NUMBERS FOR THE PAPER
# =========================================================================
print("\n" + "=" * 70)
print("FINAL SUMMARY - USE THESE EXACT NUMBERS IN THE PAPER")
print("=" * 70)
print(f"Corpus: {len(corpus_df)} clean segments (from {len(dataset['train'])} raw)")
print(f"Experiment 1 (random): N=500  |  Experiment 2 (targeted): N=200")
print(f"Labelled and cleaned: N={len(df_clean)} (2 misaligned rows excluded from 200 labelled)")
print(f"\nThree-class (refined): accuracy={result_v2['accuracy']:.3f}  macro_f1={result_v2['macro_f1']:.3f}  "
      f"(baseline={result_v2['baseline']:.3f})")
print(f"Binary (refined):      accuracy={binary_v2['accuracy']:.3f}  macro_f1={binary_v2['macro_f1']:.3f}  "
      f"(baseline={binary_v2['baseline']:.3f})")
print(f"Not Low Risk recall (refined): {binary_v2['not_low_risk_recall']:.3f}")
print(f"Low Risk recall (refined):     {binary_v2['low_risk_recall']:.3f}")
