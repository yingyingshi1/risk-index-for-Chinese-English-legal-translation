"""
Bootstrap confidence intervals for the three-class and binary classification
results reported in Tables 3 and 4 of the paper.


Usage:
    python bootstrap_confidence_intervals.py

Requires:
    data/scored/final_labelled_results_REFINED_FORMULA.csv
    (produced by COMPLETE_REPRODUCIBLE_PIPELINE.py, included in this repo)
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score

SEED = 42
N_BOOT = 5000
LABELS_3CLASS = ["Low Risk", "Medium Risk", "High Risk"]
LABELS_BINARY = ["Low Risk", "Not Low Risk"]

DATA_PATH = "../data/scored/final_labelled_results_REFINED_FORMULA.csv"


def classify_ri(ri, low_med, med_high):
    if ri >= med_high:
        return "High Risk"
    elif ri >= low_med:
        return "Medium Risk"
    return "Low Risk"


def classify_binary(ri, t):
    return "Low Risk" if ri < t else "Not Low Risk"


def calibrate_three_class(df, ri_col):
    calib_df, holdout_df = train_test_split(
        df, test_size=0.30, random_state=SEED, stratify=df["human_risk_label"]
    )
    best_f1, best_low_med, best_med_high = -1, None, None
    for low_med in np.arange(0.02, 0.60, 0.02):
        for med_high in np.arange(0.02, 0.60, 0.02):
            if med_high <= low_med:
                continue
            preds = calib_df[ri_col].apply(lambda ri: classify_ri(ri, low_med, med_high))
            f1 = f1_score(calib_df["human_risk_label"], preds, labels=LABELS_3CLASS,
                          average="macro", zero_division=0)
            if f1 > best_f1:
                best_f1, best_low_med, best_med_high = f1, low_med, med_high
    holdout_preds = holdout_df[ri_col].apply(lambda ri: classify_ri(ri, best_low_med, best_med_high))
    return {
        "low_med": best_low_med, "med_high": best_med_high,
        "holdout_df": holdout_df, "holdout_preds": holdout_preds,
    }


def calibrate_binary(df, ri_col):
    d = df.copy()
    d["binary_label"] = d["human_risk_label"].apply(lambda x: "Low Risk" if x == "Low Risk" else "Not Low Risk")
    calib_df, holdout_df = train_test_split(
        d, test_size=0.30, random_state=SEED, stratify=d["human_risk_label"]
    )
    best_f1, best_t = -1, None
    for t in np.arange(0.02, 0.60, 0.01):
        preds = calib_df[ri_col].apply(lambda ri: classify_binary(ri, t))
        f1 = f1_score(calib_df["binary_label"], preds, labels=LABELS_BINARY,
                      average="macro", zero_division=0)
        if f1 > best_f1:
            best_f1, best_t = f1, t
    holdout_preds = holdout_df[ri_col].apply(lambda ri: classify_binary(ri, best_t))
    return {"threshold": best_t, "holdout_df": holdout_df, "holdout_preds": holdout_preds}


def bootstrap_ci(true_labels, pred_labels, labels_order, n_boot=N_BOOT):
    true_labels = np.array(true_labels)
    pred_labels = np.array(pred_labels)
    n = len(true_labels)
    boot_f1, boot_acc = [], []
    for _ in range(n_boot):
        idx = np.random.randint(0, n, n)
        bt, bp = true_labels[idx], pred_labels[idx]
        boot_f1.append(f1_score(bt, bp, labels=labels_order, average="macro", zero_division=0))
        boot_acc.append(accuracy_score(bt, bp))
    boot_f1, boot_acc = np.array(boot_f1), np.array(boot_acc)
    return {
        "f1_point": f1_score(true_labels, pred_labels, labels=labels_order, average="macro", zero_division=0),
        "f1_ci": (np.percentile(boot_f1, 2.5), np.percentile(boot_f1, 97.5)),
        "acc_point": accuracy_score(true_labels, pred_labels),
        "acc_ci": (np.percentile(boot_acc, 2.5), np.percentile(boot_acc, 97.5)),
    }


def paired_bootstrap_diff(true_labels, preds_a, preds_b, labels_order, n_boot=N_BOOT):
    """95% CI on macro F1(preds_b) - macro F1(preds_a), paired over the same resamples."""
    true_labels = np.array(true_labels)
    preds_a = np.array(preds_a)
    preds_b = np.array(preds_b)
    n = len(true_labels)
    diffs = []
    for _ in range(n_boot):
        idx = np.random.randint(0, n, n)
        f1_a = f1_score(true_labels[idx], preds_a[idx], labels=labels_order, average="macro", zero_division=0)
        f1_b = f1_score(true_labels[idx], preds_b[idx], labels=labels_order, average="macro", zero_division=0)
        diffs.append(f1_b - f1_a)
    diffs = np.array(diffs)
    return diffs, (np.percentile(diffs, 2.5), np.percentile(diffs, 97.5)), (diffs > 0).mean()


def main():
    np.random.seed(SEED)
    df = pd.read_csv(DATA_PATH)

    r_v1 = calibrate_three_class(df, "Risk_Index")
    r_v2 = calibrate_three_class(df, "Risk_Index_v2")
    b_v1 = calibrate_binary(df, "Risk_Index")
    b_v2 = calibrate_binary(df, "Risk_Index_v2")

    def fmt_ci(ci):
        return f"[{float(ci[0]):.3f}, {float(ci[1]):.3f}]"

    print("=" * 70)
    print("THREE-CLASS (Table 3)")
    print("=" * 70)
    for name, r in [("Original formula", r_v1), ("Refined formula", r_v2)]:
        res = bootstrap_ci(r["holdout_df"]["human_risk_label"], r["holdout_preds"], LABELS_3CLASS)
        print(f"{name}: acc={res['acc_point']:.3f} CI{fmt_ci(res['acc_ci'])}  "
              f"macroF1={res['f1_point']:.3f} CI{fmt_ci(res['f1_ci'])}")

    print("\n" + "=" * 70)
    print("BINARY (Table 4)")
    print("=" * 70)
    for name, b in [("Original formula", b_v1), ("Refined formula", b_v2)]:
        res = bootstrap_ci(b["holdout_df"]["binary_label"], b["holdout_preds"], LABELS_BINARY)
        print(f"{name}: acc={res['acc_point']:.3f} CI{fmt_ci(res['acc_ci'])}  "
              f"macroF1={res['f1_point']:.3f} CI{fmt_ci(res['f1_ci'])}")

    print("\n" + "=" * 70)
    print("PAIRED COMPARISONS")
    print("=" * 70)
    same_split = r_v1["holdout_df"]["row_id"].tolist() == r_v2["holdout_df"]["row_id"].tolist()
    if same_split:
        _, ci, p_gt = paired_bootstrap_diff(
            r_v1["holdout_df"]["human_risk_label"], r_v1["holdout_preds"], r_v2["holdout_preds"], LABELS_3CLASS
        )
        print(f"Refined vs. original (three-class): 95% CI on difference {fmt_ci(ci)}, P(refined>original)={p_gt:.3f}")


if __name__ == "__main__":
    main()
