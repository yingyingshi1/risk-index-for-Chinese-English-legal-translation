# A dual-channel risk index for Chinese-English legal translation

Code, data, and manuscript source for:

> Shi, Y. (2026). *A dual-channel risk index for Chinese-English legal translation: Evaluating LLM translation risk on real Hong Kong court judgments.* PLOS ONE.

This repository contains everything needed to reproduce the paper's results, tables, and figures, either from the already-scored data (fast, no GPU needed) or from scratch (translation and embedding steps included).

## What this is

The paper proposes a risk index for judging whether an LLM-produced Chinese-to-English legal translation has changed a legal obligation, not just whether it "sounds right." The index combines two channels:

- **Semantic loss ($L_{sem}$)**: sentence-embedding cosine distance between the machine translation and the human reference.
- **Pragmatic legal penalty ($P_{legal}$)**: a weighted mismatch score over deontic modal words ("shall," "must," "should," "may," etc.) between the machine translation and the reference.

The two channels are combined into a single Risk Index and calibrated against blind human risk judgments on 198 real segments from the CFA Judgement Corpus 97-22 (Hong Kong Court of Final Appeal judgments, 1997-2022).

## Repository structure

```
.
├── code/
│   ├── COMPLETE_REPRODUCIBLE_PIPELINE.py   # Full pipeline: corpus loading, cleaning,
│   │                                        # sampling, translation, scoring, calibration
│   ├── bootstrap_confidence_intervals.py   # Reproduces Tables 3-4 and their 95% CIs
│   └── generate_figures.py                 # Regenerates Fig 2-7 from scored data
├── data/
│   ├── raw_annotations/                    # Blind human risk labels (the core original data)
│   │   ├── BLIND_annotation_experiment1_random_labeled.csv
│   │   └── BLIND_annotation_experiment2_targeted_labeled.csv
│   └── scored/                             # L_sem / P_legal / Risk_Index already computed
│       ├── results_experiment1_random.csv        # N=500, pre-human-labelling
│       ├── results_experiment2_targeted.csv       # N=200, pre-human-labelling
│       ├── final_labelled_results_combined.csv    # N=200, human labels merged, before cleaning
│       ├── final_labelled_results_CLEANED.csv     # N=198, after removing 2 misaligned segments
│       ├── final_labelled_results_REFINED_FORMULA.csv  # N=198, both formula versions
│       └── holdout_set.csv                        # N=60, the held-out evaluation split
├── labelling_tool/
│   └── translation_risk_labelling_tool.html # Standalone blind-annotation tool used by the annotator
├── requirements.txt
├── LICENSE
├── CITATION.cff
└── README.md
```

## Reproducing the results

### Fast path: from already-scored data (no GPU, no model downloads)

The `data/scored/` files already contain computed `L_sem`, `P_legal`, and `Risk_Index` values, so you can reproduce every number in Tables 3, 4, and 5, and every figure, without re-running translation or embedding.

```bash
pip install -r requirements.txt
cd code
python bootstrap_confidence_intervals.py   # prints Tables 3-4 with 95% CIs
python generate_figures.py                 # writes Fig2.png ... Fig7.png
```

Both scripts reproduce the exact stratified 138/60 calibration/held-out split (`train_test_split`, `random_state=42`) used throughout the paper. The point estimates you get back should match Tables 3-5 exactly:

| | Accuracy | Macro F1 |
|---|---|---|
| Three-class, baseline | 0.483 | 0.217 |
| Three-class, original formula | 0.483 | 0.350 |
| Three-class, refined formula | 0.500 | 0.409 |
| Binary, baseline | 0.650 | 0.394 |
| Binary, original/refined formula | 0.633 | 0.531 |

### Full path: from raw corpus to final results

Requires a GPU (the pipeline loads Qwen2.5-7B-Instruct in 4-bit precision) and internet access to Hugging Face for the corpus, the translation model, and the `all-mpnet-base-v2` sentence embedding model.

```bash
pip install -r requirements.txt
python -m spacy download en_core_web_sm
python code/COMPLETE_REPRODUCIBLE_PIPELINE.py
```

This script was originally run in Google Colab; the `google.colab` import and Drive-mounting code at the top will need to be removed or adapted if running elsewhere. It:

1. Loads the CFA Judgement Corpus 97-22 via the Hugging Face `datasets` library (not bundled in this repo — see "Corpus" below).
2. Cleans it (length filter, tab-artifact repair, deduplication): 11,099 → 8,094 segments.
3. Draws the two experimental samples (N=500 random, N=200 targeted).
4. Translates every segment with Qwen2.5-7B-Instruct.
5. Scores every segment on both channels.
6. Merges in the human labels from `data/raw_annotations/`.
7. Runs the automated misalignment check and threshold calibration.

### Building the manuscript PDF

```bash
cd manuscript
pdflatex manuscript.tex
bibtex manuscript
pdflatex manuscript.tex
pdflatex manuscript.tex
```

## Corpus

The CFA Judgement Corpus 97-22 itself is **not bundled in this repository**. It is third-party data (Sin et al., 2025, arXiv:2501.09444) and is loaded directly from the Hugging Face `datasets` library in `COMPLETE_REPRODUCIBLE_PIPELINE.py`. This avoids redistributing a corpus this repository doesn't hold the rights to, and ensures you always get the authoritative version.

## Data quality notes

- `final_labelled_results_combined.csv` (N=200) includes 2 segments later confirmed as genuine source-reference misalignments (see paper, Methods: Data quality verification). These are removed in `final_labelled_results_CLEANED.csv` and all files derived from it (N=198).
- Two segments used to illustrate the formula-refinement effect (Table 5 in the paper) come from different splits: `experiment1_random_290` is in the calibration set, `experiment2_targeted_182` is in the held-out set. This is disclosed explicitly in the paper's Methods and Discussion sections; see there for why this does not contaminate the reported performance figures.
- All human labels in `data/raw_annotations/` come from a single annotator. No second rater was used. This is a stated limitation of the study, not an artifact of the data files.

## Data license

The data in `data/` (the blind human risk annotations and derived scores) is released under **CC BY 4.0** (Creative Commons Attribution 4.0). This is a suggested default for research data of this kind; if you want different terms, update this section and the corresponding license note before making the repository public.

The code in `code/` and `manuscript/` is released under the **MIT License** (see `LICENSE`).

## Citation

See `CITATION.cff`, or cite:

```bibtex
@article{shi2026dualchannel,
  title   = {A dual-channel risk index for Chinese-English legal translation: Evaluating LLM translation risk on real Hong Kong court judgments},
  author  = {Shi, Yingying},
  journal = {PLOS ONE},
  year    = {2026}
}
```

## Contact

Yingying Shi — yingyingshi1@outlook.com
School of Foreign Languages, Hunan University of Arts and Sciences, Changde, Hunan, China
